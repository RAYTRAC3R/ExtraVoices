1.0.4
- Networking seems to work!
- You no longer have to restart the game to change your voice! From now on you just need to save your changes in TackleBox, and it should change instantly.
- Added ability to choose a default voice for other players who don't have the mod.

1.0.3
- Attempt at networking, still needs testing. In theory, anyone who has the mod and a voicebank installed should be able to hear you speak with it.

1.0.2
- Added Minty voice
- Added Dhama voice
- Added the ability to use custom voicebanks

1.0.1
- Removed Animalese voice at request of mod creator, however now you can install the Animalese mod separately and use it with this one.

1.0.0
- Created mod
- Added Animalese voice