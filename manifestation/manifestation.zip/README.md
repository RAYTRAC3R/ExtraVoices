Mod to swap out the player's voice using a config. Other mods can contain voicebanks that can be used as an extra voice if installed.

If others have the mod installed and you have the voicebank they're currently using, you'll hear their chosen voice! If you're missing the voice they chose, you'll hear silence. If they don't have the mod at all, you'll hear a voice that you choose in your settings.

Current Options:
- NewVoice (Base game)
- OldVoice (Base game unused)
- Minty (Included with this mod)
- Dhama (Included with this mod)
- Animalese (If separate mod installed) https://thunderstore.io/c/webfishing/p/Eavontide/Animalese/
- Miku (If separate mod installed) https://thunderstore.io/c/webfishing/p/kitifulnines/MikuVoice/
- And possibly more!

Follow this tutorial to make your own voices: https://youtu.be/Y8eBRdbQPiA
Feel free to include this mod in let's plays or mod showcases (with credit!)